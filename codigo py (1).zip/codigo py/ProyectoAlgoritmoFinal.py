from registro import registrar_usuario
from login import iniciar_sesion

from citas_acciones import (
    agendar_cita,
    ver_citas,
    cancelar_cita,
    reprogramar_cita
)

from json_utils import cargar_usuarios


usuarios, citas = cargar_usuarios()


while True:

    print("\nEPS VIDA SANA")

    print("1. Registrarse")
    print("2. Iniciar sesión")
    print("3. Salir")

    op = input("Seleccione: ")

    if op == "1":

        registrar_usuario(usuarios, citas)

    elif op == "2":

        user = iniciar_sesion(usuarios)

        if user:

            while True:

                print("\nMENÚ USUARIO")

                print("1. Agendar cita")
                print("2. Ver citas")
                print("3. Cancelar cita")
                print("4. Reprogramar cita")
                print("5. Cerrar sesión")

                opcion = input("Seleccione: ")

                if opcion == "1":

                    agendar_cita(citas, user)

                elif opcion == "2":

                    ver_citas(citas, user)

                elif opcion == "3":

                    cancelar_cita(citas, user)

                elif opcion == "4":

                    reprogramar_cita(citas, user)

                elif opcion == "5":

                    print("Sesión cerrada.")
                    break

                else:

                    print("Opción inválida.")

    elif op == "3":

        print("Sistema finalizado.")
        break

    else:

        print("Opción inválida.")