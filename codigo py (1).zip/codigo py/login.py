def iniciar_sesion(usuarios):

    print("\nLOGIN")

    doc = input("Documento: ").strip()

    password = input("Contraseña: ").strip()

    if doc not in usuarios:

        print("Usuario no existe.")
        return None

    if usuarios[doc].password != password:

        print("Contraseña incorrecta.")
        return None

    print(f"Bienvenido {usuarios[doc].nombre}")

    return doc