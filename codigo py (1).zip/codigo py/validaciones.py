from datetime import datetime


def validar_numero(texto):

    return texto.isdigit()


def validar_nombre(texto):

    return texto.replace(" ", "").isalpha()


def validar_fecha_hora(fecha, hora):

    try:

        fecha_dt = datetime.strptime(fecha, "%d/%m/%Y")

        datetime.strptime(hora, "%H:%M")

        if fecha_dt.date() < datetime.now().date():

            print("No puedes agendar en fechas pasadas.")
            return False

        return True

    except:

        print("Formato inválido.")
        return False