import json

from usuario import Usuario


def guardar_usuarios(usuarios):

    datos = {}

    for doc, usuario in usuarios.items():

        datos[doc] = {
            "documento": usuario.documento,
            "nombre": usuario.nombre,
            "password": usuario.password
        }

    with open("usuarios.json", "w", encoding="utf-8") as archivo:

        json.dump(datos, archivo, indent=4, ensure_ascii=False)


def cargar_usuarios():

    usuarios = {}
    citas = {}

    try:

        with open("usuarios.json", "r", encoding="utf-8") as archivo:

            datos = json.load(archivo)

            for doc, info in datos.items():

                usuarios[doc] = Usuario(
                    info["documento"],
                    info["nombre"],
                    info["password"]
                )

                citas[doc] = []

    except FileNotFoundError:

        pass

    return usuarios, citas