class Cita:

    def __init__(self, fecha, hora, sede):

        self.fecha = fecha
        self.hora = hora
        self.sede = sede

    def __str__(self):

        return f"Cita - {self.fecha} a las {self.hora} | {self.sede}"


class CitaMedico(Cita):

    def __init__(self, fecha, hora, sede, motivo):

        super().__init__(fecha, hora, sede)

        self.motivo = motivo

    def __str__(self):

        return (f"Médico general - {self.fecha} a las {self.hora} | "
                f"{self.sede} | Motivo: {self.motivo}")


class CitaPsicologia(Cita):

    SESIONES = {
        "1": "Primera vez",
        "2": "Seguimiento",
        "3": "Cierre"
    }

    def __init__(self, fecha, hora, sede, sesion):

        super().__init__(fecha, hora, sede)

        self.sesion = sesion

    def __str__(self):

        return (f"Psicología - {self.fecha} a las {self.hora} | "
                f"{self.sede} | Sesión: {self.sesion}")


class CitaMuestras(Cita):

    def __init__(self, fecha, hora, sede, tipo_muestra):

        super().__init__(fecha, hora, sede)

        self.tipo_muestra = tipo_muestra

    def __str__(self):

        return (f"Toma de muestras - {self.fecha} a las {self.hora} | "
                f"{self.sede} | Muestra: {self.tipo_muestra}")


class CitaOdontologia(Cita):

    def __init__(self, fecha, hora, sede, procedimiento):

        super().__init__(fecha, hora, sede)

        self.procedimiento = procedimiento

    def __str__(self):

        return (f"Odontología - {self.fecha} a las {self.hora} | "
                f"{self.sede} | Procedimiento: {self.procedimiento}")


class CitaEspecialista(Cita):

    def __init__(self, fecha, hora, sede, especialidad):

        super().__init__(fecha, hora, sede)

        self.especialidad = especialidad

    def __str__(self):

        return (f"Especialista ({self.especialidad}) - "
                f"{self.fecha} a las {self.hora} | {self.sede}")