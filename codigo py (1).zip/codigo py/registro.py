from usuario import Usuario

from validaciones import (
    validar_numero,
    validar_nombre
)

from json_utils import guardar_usuarios


def registrar_usuario(usuarios, citas):

    print("\nREGISTRO")

    doc = input("Documento: ").strip()

    if not validar_numero(doc):

        print("El documento solo puede contener números.")
        return

    if doc in usuarios:

        print("Usuario ya existe.")
        return

    nombre = input("Nombre completo: ").strip()

    if not validar_nombre(nombre):

        print("El nombre solo puede contener letras.")
        return

    password = input("Contraseña: ").strip()

    if not validar_numero(password):

        print("La contraseña solo puede contener números.")
        return

    usuarios[doc] = Usuario(doc, nombre, password)

    citas[doc] = []

    guardar_usuarios(usuarios)

    print("Usuario registrado correctamente.")