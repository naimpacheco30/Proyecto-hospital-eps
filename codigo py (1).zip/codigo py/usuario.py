class Usuario:

    def __init__(self, documento, nombre, password):

        self.documento = documento
        self.nombre = nombre
        self.password = password