from validaciones import validar_fecha_hora

from sedes import seleccionar_sede

from citas import (
    CitaMedico,
    CitaPsicologia,
    CitaMuestras,
    CitaOdontologia,
    CitaEspecialista
)


def agendar_cita(citas, doc):

    print("\nAGENDAR CITA")

    print("1. Médico general")
    print("2. Psicología")
    print("3. Toma de muestras")
    print("4. Odontología")
    print("5. Especialista")

    opcion = input("Seleccione tipo de cita: ")

    fecha = input("Fecha (DD/MM/AAAA): ")
    hora = input("Hora (HH:MM): ")

    if not validar_fecha_hora(fecha, hora):

        return

    sede = seleccionar_sede()

    if not sede:

        return

    if opcion == "1":

        motivo = input("Motivo: ")

        nueva = CitaMedico(fecha, hora, sede, motivo)

    elif opcion == "2":

        for k, v in CitaPsicologia.SESIONES.items():

            print(f"{k}. {v}")

        op = input("Seleccione: ")

        sesion = CitaPsicologia.SESIONES.get(op, "Seguimiento")

        nueva = CitaPsicologia(fecha, hora, sede, sesion)

    elif opcion == "3":

        muestra = input("Tipo de muestra: ")

        nueva = CitaMuestras(fecha, hora, sede, muestra)

    elif opcion == "4":

        procedimiento = input("Procedimiento: ")

        nueva = CitaOdontologia(fecha, hora, sede, procedimiento)

    elif opcion == "5":

        especialidad = input("Especialidad: ")

        nueva = CitaEspecialista(fecha, hora, sede, especialidad)

    else:

        print("Opción inválida.")
        return

    citas[doc].append(nueva)

    print("Cita agendada correctamente.")


def ver_citas(citas, doc):

    print("\nMIS CITAS")

    if not citas.get(doc):

        print("No tienes citas.")
        return

    for i, c in enumerate(citas[doc]):

        print(f"{i+1}. {c}")


def cancelar_cita(citas, doc):

    ver_citas(citas, doc)

    try:

        num = int(input("Número: "))

        eliminada = citas[doc].pop(num - 1)

        print(f"Cita cancelada: {eliminada}")

    except:

        print("Entrada inválida.")


def reprogramar_cita(citas, doc):

    ver_citas(citas, doc)

    try:

        num = int(input("Número: "))

        nueva_fecha = input("Nueva fecha: ")
        nueva_hora = input("Nueva hora: ")

        citas[doc][num - 1].fecha = nueva_fecha
        citas[doc][num - 1].hora = nueva_hora

        print("Cita reprogramada.")

    except:

        print("Entrada inválida.")