def seleccionar_sede():

    sedes = {

        "1": {
            "nombre": "Sede Centro",
            "direccion": "Calle 30 # 45-12"
        },

        "2": {
            "nombre": "Sede Norte",
            "direccion": "Calle 84 # 53-20"
        },

        "3": {
            "nombre": "Sede Sur",
            "direccion": "Carrera 7 Sur # 72-15"
        }
    }

    print("\nSELECCIONE SEDE EPS")

    for k, v in sedes.items():

        print(f"{k}. {v['nombre']}")

    op = input("Seleccione sede: ")

    if op not in sedes:

        print("Sede inválida.")
        return None

    return f"{sedes[op]['nombre']} - {sedes[op]['direccion']}"